# Arbiter AI: checkpoint at 26,002 records

Stopped at the requested threshold of 26,000; 26,002 completed results are preserved.

Dataset: AIT Alert Data Set (AIT-ADS) v1, DOI 10.5281/zenodo.8263181, Max Landauer, Florian Skopik and Markus Wurzenberger, AIT Austrian Institute of Technology, CC BY 4.0. Source: https://zenodo.org/records/8263181 . The full supported population is 2,600,263 Wazuh/Suricata records; 55,558 AMiner records are unsupported.

This package contains the first records in file order from {'fox': 26002}. It is a partial, non-random replay, not a completed full-dataset evaluation.

- Attack-labelled records examined: 0; kept flagged: 0; quieted: 0.
- Records without attack labels: 26,002; quieted: 14,957; still flagged: 11,045.
- Agreement with publisher labels: 57.52%. Missing attack labels do not certify harmlessness.
- Qwen reviews: 11,310; Gemma records with replies: 43; warnings quieted by Gemma: 39.
- Qwen errors: 0; L2 errors: 0. No device actions were enabled.

Attack detection cannot be estimated when the examined prefix contains no attack labels. The separate L2 security-context upgrade was not applied to this frozen run.

Open results.csv for a spreadsheet, decisions.jsonl for complete per-record evidence, summary.json for exact counts, and results.db for the SQLite snapshot. CSV formula-like strings are escaped; JSONL/SQLite retain exact values. run.json fixes model identities, input provenance and evaluated source hashes. SHA256SUMS.txt covers this package.

The final in-flight attempt may have been interrupted at the stop; it is journalled and is not a completed/scored result. Completed records were not deleted, rewritten or retried. The original run remains resumable if explicitly restarted.
