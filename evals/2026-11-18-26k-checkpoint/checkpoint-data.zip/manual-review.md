### What checking Gemma's explanations revealed

Gemma's challenge accepted all 43 completed model reviews with no objections.
That is a software/critic outcome, not an independent correctness score. Reading
the saved explanations exposed limitations in both directions:

- **fox:2244, suppressed:** Gemma described a redirect to the administrator
  dashboard. The source log contains a 302 response and an administrator target
  inside the referring page's `redirect_to` parameter. It does not record the
  response's actual destination or a completed authenticated session. The
  explanation states more than the saved evidence establishes.
- **fox:22015, retained:** Gemma interpreted a request mentioning a payroll
  spreadsheet as a targeted data-exfiltration attempt. The record shows a
  file-sharing API request and a 500 server error. The sensitive filename can
  justify investigation, but it does not establish unauthorized access or data
  transfer. Retaining uncertainty fits the policy; the explanation should label
  the attack interpretation as a possibility rather than treating the filename
  as sufficient attribution.
- **fox:25772, suppressed:** Gemma used a generic 500 error and absence of
  confirmed exploit success to justify quieting the warning. A server error does
  not establish an ordinary root cause or rule out an attack attempt. The saved
  challenge accepted this reasoning without objection, and no final veto fired.

These are illustrative qualitative findings, not an independently adjudicated
semantic error rate. They do not change the saved decisions or publisher-label
scores. None of these records has an attack annotation, so they cannot be called
proven missed attacks. Equally, the 39 label-agreeing Gemma suppressions must not
be described as 39 independently verified safe decisions. The next evaluation
needs ordinary/malicious HTTP lookalikes and independent review of the reasons,
alongside the routing fix and richer evidence.
